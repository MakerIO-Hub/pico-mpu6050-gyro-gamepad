#include <Adafruit_TinyUSB.h>
#include <Wire.h>

// =====================================================
// USB GAMEPAD
// =====================================================

uint8_t const desc_hid_report[] = {
  TUD_HID_REPORT_DESC_GAMEPAD()
};

Adafruit_USBD_HID usb_hid(
  desc_hid_report,
  sizeof(desc_hid_report),
  HID_ITF_PROTOCOL_NONE,
  2,
  false
);

// =====================================================
// BUTONLAR — Pico Doğrudan GPIO
// =====================================================

// D-PAD
#define PIN_DPAD_UP       2
#define PIN_DPAD_DOWN     3
#define PIN_DPAD_LEFT     4
#define PIN_DPAD_RIGHT    5

// A / B / X / Y
#define PIN_A             6
#define PIN_B             7
#define PIN_X             8
#define PIN_Y             9

// LB / RB
#define PIN_LB            10
#define PIN_RB            11

// START / SELECT
#define PIN_START         12
#define PIN_SELECT        13

// Yeni 12 Buton
#define PIN_BTN1          14
#define PIN_BTN2          15
#define PIN_BTN3          16
#define PIN_BTN4          17
#define PIN_BTN5          18
#define PIN_BTN6          19
#define PIN_BTN7          20
#define PIN_BTN8          21
#define PIN_BTN9          22
#define PIN_BTN10         26
#define PIN_BTN11         27
#define PIN_BTN12         28

// =====================================================
// MPU6050
// =====================================================

#define MPU_ADDR        0x68
#define MPU_GYRO_ZOUT_H 0x47
#define GYRO_SCALE      131.0

// =====================================================
// DİREKSİYON AYARLARI
// =====================================================

//
// MAX_STEERING_ANGLE: Kaç derece döndürünce tam uca gelsin
// 60° = hassas, az hareket yeterli
// 70° = standart
// 90° = geniş, gerçekçi
//
const float MAX_STEERING_ANGLE = 65.0;
//
// GYRO_DEADBAND: Bu değerin altındaki gyro hareketi yoksayılır
// Küçük → Daha duyarlı ama titreme olabilir
// Büyük → Daha stabil ama az hassas
const float GYRO_DEADBAND = 0.5;

const float CENTER_FORCE = 1.5;

const float SMOOTH_HEAVY  = 0.35;
const float SMOOTH_MEDIUM = 0.45;
const float SMOOTH_LIGHT  = 0.55;

float steeringAngle  = 0.0;
float gyroBiasZ      = 0.0;
float smoothSteering = 0.0;

unsigned long previousMicros = 0;

// =====================================================
// LED (Pico dahili)
// =====================================================

#define LED_PIN 25

// =====================================================
// MPU6050 REGISTER YAZ
// =====================================================

void writeMPU(byte reg, byte data) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(data);
  Wire.endTransmission(true);
}

// =====================================================
// MPU6050 GYRO Z OKU
// =====================================================

int16_t readGyroZRaw() {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(MPU_GYRO_ZOUT_H);
  Wire.endTransmission(false);

  Wire.requestFrom(MPU_ADDR, 2, true);

  if (Wire.available() < 2) {
    return 0;
  }

  return ((int16_t)Wire.read() << 8) | Wire.read();
}

// =====================================================
// GYRO KALİBRASYONU
// LED yanıp söner → Hareketsiz tutun!
// LED sabit → Hazır
// =====================================================

void calibrateGyro() {

  long toplam = 0;
  const int samples = 1000;

  for (int i = 0; i < samples; i++) {
    digitalWrite(LED_PIN, (i % 80 < 40) ? HIGH : LOW);
    toplam += readGyroZRaw();
    delay(2);
  }

  gyroBiasZ = (float)toplam / samples;

  digitalWrite(LED_PIN, HIGH);
}


// =====================================================
// SETUP
// =====================================================

void setup() {

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // ---------------------------------------------------
  // USB HID
  // ---------------------------------------------------

  usb_hid.begin();

  while (!TinyUSBDevice.mounted()) {
    delay(1);
  }

  // ---------------------------------------------------
  // BUTONLAR — Mevcut 12
  // ---------------------------------------------------

  pinMode(PIN_DPAD_UP,    INPUT_PULLUP);
  pinMode(PIN_DPAD_DOWN,  INPUT_PULLUP);
  pinMode(PIN_DPAD_LEFT,  INPUT_PULLUP);
  pinMode(PIN_DPAD_RIGHT, INPUT_PULLUP);

  pinMode(PIN_A,      INPUT_PULLUP);
  pinMode(PIN_B,      INPUT_PULLUP);
  pinMode(PIN_X,      INPUT_PULLUP);
  pinMode(PIN_Y,      INPUT_PULLUP);

  pinMode(PIN_LB,     INPUT_PULLUP);
  pinMode(PIN_RB,     INPUT_PULLUP);

  pinMode(PIN_START,  INPUT_PULLUP);
  pinMode(PIN_SELECT, INPUT_PULLUP);

  // ---------------------------------------------------
  // BUTONLAR — Yeni 12
  // ---------------------------------------------------

  pinMode(PIN_BTN1,  INPUT_PULLUP);
  pinMode(PIN_BTN2,  INPUT_PULLUP);
  pinMode(PIN_BTN3,  INPUT_PULLUP);
  pinMode(PIN_BTN4,  INPUT_PULLUP);
  pinMode(PIN_BTN5,  INPUT_PULLUP);
  pinMode(PIN_BTN6,  INPUT_PULLUP);
  pinMode(PIN_BTN7,  INPUT_PULLUP);
  pinMode(PIN_BTN8,  INPUT_PULLUP);
  pinMode(PIN_BTN9,  INPUT_PULLUP);
  pinMode(PIN_BTN10, INPUT_PULLUP);
  pinMode(PIN_BTN11, INPUT_PULLUP);
  pinMode(PIN_BTN12, INPUT_PULLUP);

  // ---------------------------------------------------
  // MPU6050
  // ---------------------------------------------------

  Wire.setSDA(0);
  Wire.setSCL(1);
  Wire.begin();
  Wire.setClock(400000);

  writeMPU(0x6B, 0x00);   // Uyandır
  delay(100);
  writeMPU(0x1B, 0x00);   // Gyro ±250°/s
  writeMPU(0x1A, 0x03);   // DLPF 42Hz
  delay(100);

  // ---------------------------------------------------
  // GYRO KALİBRASYONU — DİREKSİYONU HAREKETSİZ TUTUN!
  // ---------------------------------------------------

  calibrateGyro();

  steeringAngle  = 0.0;
  smoothSteering = 0.0;
  previousMicros = micros();
}

// =====================================================
// LOOP
// =====================================================

void loop() {

  if (!usb_hid.ready()) {
    return;
  }

  // ===================================================
  // ZAMAN HESABI
  // ===================================================

  unsigned long now = micros();
  float dt = (now - previousMicros) / 1000000.0;
  previousMicros = now;

  if (dt <= 0.0 || dt > 0.1) dt = 0.004;

  // ===================================================
  // GYRO OKU VE İŞLE
  // ===================================================

  int16_t rawGyroZ = readGyroZRaw();

  float gyroZ = -((float)rawGyroZ - gyroBiasZ) / GYRO_SCALE;

  if (fabs(gyroZ) < GYRO_DEADBAND) gyroZ = 0.0;

  // ===================================================
  // DİREKSİYON AÇISI
  // ===================================================

  steeringAngle += gyroZ * dt;

  // ===================================================
  // AUTO-CENTER (Kayar gibi yavaş merkeze dönüş)
  // Gyro sessizken merkeze doğru akıcı şekilde süzülür
  // ===================================================

  if (gyroZ == 0.0 && CENTER_FORCE > 0.0) {
    steeringAngle *= (1.0 - CENTER_FORCE * dt);

    if (fabs(steeringAngle) < 0.3) {
      steeringAngle = 0.0;
    }
  }

  // ===================================================
  // SINIRLA
  // ===================================================

  if (steeringAngle >  MAX_STEERING_ANGLE) steeringAngle =  MAX_STEERING_ANGLE;
  if (steeringAngle < -MAX_STEERING_ANGLE) steeringAngle = -MAX_STEERING_ANGLE;

  // ===================================================
  // START + SELECT → ANINDA MERKEZLEME
  // ===================================================

  if (
    digitalRead(PIN_START)  == LOW &&
    digitalRead(PIN_SELECT) == LOW
  ) {
    steeringAngle  = 0.0;
    smoothSteering = 0.0;
    delay(300);
  }

  // ===================================================
  // DİREKSİYON AÇISI → HID DEĞER (Orijinal ile aynı, basit lineer)
  // ===================================================

  int targetSteering = map(
    (int)steeringAngle,
    -(int)MAX_STEERING_ANGLE,
     (int)MAX_STEERING_ANGLE,
    -127, 127
  );

  // ===================================================
  // ADAPTİF SMOOTHING — Kayar gibi his için
  // ===================================================

  float speed = fabs(gyroZ);
  float alpha;

  if      (speed > 25.0) alpha = SMOOTH_LIGHT;   // Hızlı dönüş → çabuk tepki
  else if (speed > 8.0)  alpha = SMOOTH_MEDIUM;   // Orta
  else                   alpha = SMOOTH_HEAVY;    // Yavaş/durgun → yumuşak kayış

  smoothSteering =
    (smoothSteering * (1.0 - alpha)) +
    (targetSteering * alpha);

  int steeringX = (int)smoothSteering;

  // ===================================================
  // D-PAD
  // ===================================================

  bool up    = digitalRead(PIN_DPAD_UP)    == LOW;
  bool down  = digitalRead(PIN_DPAD_DOWN)  == LOW;
  bool left  = digitalRead(PIN_DPAD_LEFT)  == LOW;
  bool right = digitalRead(PIN_DPAD_RIGHT) == LOW;

  uint8_t hat = GAMEPAD_HAT_CENTERED;

  if      (up && right)   hat = GAMEPAD_HAT_UP_RIGHT;
  else if (down && right) hat = GAMEPAD_HAT_DOWN_RIGHT;
  else if (down && left)  hat = GAMEPAD_HAT_DOWN_LEFT;
  else if (up && left)    hat = GAMEPAD_HAT_UP_LEFT;
  else if (up)            hat = GAMEPAD_HAT_UP;
  else if (down)          hat = GAMEPAD_HAT_DOWN;
  else if (left)          hat = GAMEPAD_HAT_LEFT;
  else if (right)         hat = GAMEPAD_HAT_RIGHT;

  // ===================================================
  // BUTONLAR
  // ===================================================

  uint32_t buttons = 0;

  // Mevcut 8 buton (bit 0–7)
  if (digitalRead(PIN_A)      == LOW) buttons |= (1UL << 0);
  if (digitalRead(PIN_B)      == LOW) buttons |= (1UL << 1);
  if (digitalRead(PIN_X)      == LOW) buttons |= (1UL << 2);
  if (digitalRead(PIN_Y)      == LOW) buttons |= (1UL << 3);
  if (digitalRead(PIN_LB)     == LOW) buttons |= (1UL << 4);
  if (digitalRead(PIN_RB)     == LOW) buttons |= (1UL << 5);
  if (digitalRead(PIN_START)  == LOW) buttons |= (1UL << 6);
  if (digitalRead(PIN_SELECT) == LOW) buttons |= (1UL << 7);

  // Yeni 12 buton (bit 8–19)
  if (digitalRead(PIN_BTN1)  == LOW) buttons |= (1UL << 8);
  if (digitalRead(PIN_BTN2)  == LOW) buttons |= (1UL << 9);
  if (digitalRead(PIN_BTN3)  == LOW) buttons |= (1UL << 10);
  if (digitalRead(PIN_BTN4)  == LOW) buttons |= (1UL << 11);
  if (digitalRead(PIN_BTN5)  == LOW) buttons |= (1UL << 12);
  if (digitalRead(PIN_BTN6)  == LOW) buttons |= (1UL << 13);
  if (digitalRead(PIN_BTN7)  == LOW) buttons |= (1UL << 14);
  if (digitalRead(PIN_BTN8)  == LOW) buttons |= (1UL << 15);
  if (digitalRead(PIN_BTN9)  == LOW) buttons |= (1UL << 16);
  if (digitalRead(PIN_BTN10) == LOW) buttons |= (1UL << 17);
  if (digitalRead(PIN_BTN11) == LOW) buttons |= (1UL << 18);
  if (digitalRead(PIN_BTN12) == LOW) buttons |= (1UL << 19);

  // ===================================================
  // GAMEPAD RAPORU
  // ===================================================

  hid_gamepad_report_t report = {};

  report.x       = (int8_t)steeringX;
  report.y       = 0;
  report.z       = 0;
  report.rz      = 0;
  report.rx      = 0;
  report.ry      = 0;
  report.hat     = hat;
  report.buttons = buttons;

  usb_hid.sendReport(0, &report, sizeof(report));

  // ===================================================
  // LOOP HIZI — 4ms (250Hz)
  // ===================================================

  delay(4);
}